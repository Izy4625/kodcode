﻿namespace collageTop
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtCname = new System.Windows.Forms.TextBox();
            this.txtMname = new System.Windows.Forms.TextBox();
            this.txtSD = new System.Windows.Forms.TextBox();
            this.txtDay = new System.Windows.Forms.TextBox();
            this.txtHour = new System.Windows.Forms.TextBox();
            this.txtPri = new System.Windows.Forms.TextBox();
            this.lblCname = new System.Windows.Forms.Label();
            this.lblMname = new System.Windows.Forms.Label();
            this.lblSDate = new System.Windows.Forms.Label();
            this.lblDayOfW = new System.Windows.Forms.Label();
            this.lblHour = new System.Windows.Forms.Label();
            this.lblPrice = new System.Windows.Forms.Label();
            this.btnEnter = new System.Windows.Forms.Button();
            this.btnEnterSch = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtCname
            // 
            this.txtCname.Location = new System.Drawing.Point(484, 111);
            this.txtCname.Name = "txtCname";
            this.txtCname.Size = new System.Drawing.Size(100, 26);
            this.txtCname.TabIndex = 0;
            // 
            // txtMname
            // 
            this.txtMname.Location = new System.Drawing.Point(484, 226);
            this.txtMname.Name = "txtMname";
            this.txtMname.Size = new System.Drawing.Size(100, 26);
            this.txtMname.TabIndex = 1;
            // 
            // txtSD
            // 
            this.txtSD.Location = new System.Drawing.Point(484, 341);
            this.txtSD.Name = "txtSD";
            this.txtSD.Size = new System.Drawing.Size(100, 26);
            this.txtSD.TabIndex = 2;
            // 
            // txtDay
            // 
            this.txtDay.Location = new System.Drawing.Point(172, 111);
            this.txtDay.Name = "txtDay";
            this.txtDay.Size = new System.Drawing.Size(100, 26);
            this.txtDay.TabIndex = 3;
            // 
            // txtHour
            // 
            this.txtHour.Location = new System.Drawing.Point(172, 215);
            this.txtHour.Name = "txtHour";
            this.txtHour.Size = new System.Drawing.Size(100, 26);
            this.txtHour.TabIndex = 4;
            // 
            // txtPri
            // 
            this.txtPri.Location = new System.Drawing.Point(484, 412);
            this.txtPri.Name = "txtPri";
            this.txtPri.Size = new System.Drawing.Size(100, 26);
            this.txtPri.TabIndex = 5;
            // 
            // lblCname
            // 
            this.lblCname.AutoSize = true;
            this.lblCname.Location = new System.Drawing.Point(639, 116);
            this.lblCname.Name = "lblCname";
            this.lblCname.Size = new System.Drawing.Size(106, 20);
            this.lblCname.TabIndex = 6;
            this.lblCname.Text = "Course Name";
            // 
            // lblMname
            // 
            this.lblMname.AutoSize = true;
            this.lblMname.Location = new System.Drawing.Point(643, 242);
            this.lblMname.Name = "lblMname";
            this.lblMname.Size = new System.Drawing.Size(116, 20);
            this.lblMname.TabIndex = 7;
            this.lblMname.Text = "Machzor Name";
            // 
            // lblSDate
            // 
            this.lblSDate.AutoSize = true;
            this.lblSDate.Location = new System.Drawing.Point(643, 353);
            this.lblSDate.Name = "lblSDate";
            this.lblSDate.Size = new System.Drawing.Size(80, 20);
            this.lblSDate.TabIndex = 8;
            this.lblSDate.Text = "Start date";
            this.lblSDate.Click += new System.EventHandler(this.lblSDate_Click);
            // 
            // lblDayOfW
            // 
            this.lblDayOfW.AutoSize = true;
            this.lblDayOfW.Location = new System.Drawing.Point(312, 117);
            this.lblDayOfW.Name = "lblDayOfW";
            this.lblDayOfW.Size = new System.Drawing.Size(123, 20);
            this.lblDayOfW.TabIndex = 9;
            this.lblDayOfW.Text = "Day of the week";
            this.lblDayOfW.Click += new System.EventHandler(this.label4_Click);
            // 
            // lblHour
            // 
            this.lblHour.AutoSize = true;
            this.lblHour.Location = new System.Drawing.Point(341, 231);
            this.lblHour.Name = "lblHour";
            this.lblHour.Size = new System.Drawing.Size(52, 20);
            this.lblHour.TabIndex = 10;
            this.lblHour.Text = "Hours";
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.Location = new System.Drawing.Point(655, 418);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(44, 20);
            this.lblPrice.TabIndex = 11;
            this.lblPrice.Text = "Price";
            // 
            // btnEnter
            // 
            this.btnEnter.Location = new System.Drawing.Point(509, 476);
            this.btnEnter.Name = "btnEnter";
            this.btnEnter.Size = new System.Drawing.Size(75, 43);
            this.btnEnter.TabIndex = 12;
            this.btnEnter.Text = "Enter";
            this.btnEnter.UseVisualStyleBackColor = true;
            this.btnEnter.Click += new System.EventHandler(this.btnEnter_Click);
            // 
            // btnEnterSch
            // 
            this.btnEnterSch.Location = new System.Drawing.Point(194, 296);
            this.btnEnterSch.Name = "btnEnterSch";
            this.btnEnterSch.Size = new System.Drawing.Size(75, 30);
            this.btnEnterSch.TabIndex = 13;
            this.btnEnterSch.Text = "Enter";
            this.btnEnterSch.UseVisualStyleBackColor = true;
            this.btnEnterSch.Click += new System.EventHandler(this.btnEnterSch_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(326, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(144, 20);
            this.label1.TabIndex = 14;
            this.label1.Text = "Start New Machzor";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 531);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnEnterSch);
            this.Controls.Add(this.btnEnter);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(this.lblHour);
            this.Controls.Add(this.lblDayOfW);
            this.Controls.Add(this.lblSDate);
            this.Controls.Add(this.lblMname);
            this.Controls.Add(this.lblCname);
            this.Controls.Add(this.txtPri);
            this.Controls.Add(this.txtHour);
            this.Controls.Add(this.txtDay);
            this.Controls.Add(this.txtSD);
            this.Controls.Add(this.txtMname);
            this.Controls.Add(this.txtCname);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtCname;
        private System.Windows.Forms.TextBox txtMname;
        private System.Windows.Forms.TextBox txtSD;
        private System.Windows.Forms.TextBox txtDay;
        private System.Windows.Forms.TextBox txtHour;
        private System.Windows.Forms.TextBox txtPri;
        private System.Windows.Forms.Label lblCname;
        private System.Windows.Forms.Label lblMname;
        private System.Windows.Forms.Label lblSDate;
        private System.Windows.Forms.Label lblDayOfW;
        private System.Windows.Forms.Label lblHour;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.Button btnEnter;
        private System.Windows.Forms.Button btnEnterSch;
        private System.Windows.Forms.Label label1;
    }
}

